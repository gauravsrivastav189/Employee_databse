<?php
       include('configall.php');
       
       $sql="SELECT * FROM department;";
       $result=mysqli_query($connection,$sql);
       
       
       ?>